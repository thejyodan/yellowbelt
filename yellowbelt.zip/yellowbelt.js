

function removeNode(){
    const myDiv = document.getElementById("warningcard");
    const parent = myDiv.parentNode;
    parent.removeChild(myDiv);
}

function setNewImage(){
    document.getElementById("img1").src ="./images 9.13.03 AM/assets/aloe-s.jpg"
}

function setOldImage(){
    document.getElementById("img1").src ="./images 9.13.03 AM/assets/aloe-m.jpg"

}

